from db import get_db
from bson import ObjectId

from utils import get_current_user


async def resolve_search_vendors(_, info, username=None, name=None, city=None, province=None, businessCategoryId=None):
    """Search vendors based on filters like username, name, city, province, or business category."""
    db = get_db()
    query = {}
    if username:
        query["username"] = {"$regex": username, "$options": "i"}
    if name:
        query["name"] = {"$regex": name, "$options": "i"}
    if city:
        query["city"] = city
    if province:
        query["province"] = province
    if businessCategoryId:
        query["business_category_ids"] = ObjectId(businessCategoryId)

    vendors = db.vendors.find(query)
    return [{"id": str(v["_id"]), **{k: v for k, v in v.items() if k != "_id"}} for v in vendors]


# توابع قبلی vendor که احتمالاً هستن
async def resolve_my_vendor_profile(_, info):
    db = get_db()
    user_id = get_current_user(info, db)
    vendor = db.vendors.find_one({"created_by": user_id})
    if vendor:
        vendor["id"] = str(vendor["_id"])
        del vendor["_id"]
    return vendor


async def resolve_vendor_profile(_, info, vendorId):
    db = get_db()
    vendor = db.vendors.find_one({"_id": ObjectId(vendorId)})
    if not vendor:
        raise ValueError(f"Vendor with ID {vendorId} not found")
    vendor["id"] = str(vendor["_id"])
    del vendor["_id"]
    return vendor