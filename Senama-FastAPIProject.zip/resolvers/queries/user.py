from db import get_db
from bson import ObjectId
from utils import get_current_user

async def resolve_user_profile(_, info):
    """Retrieve the profile of the currently authenticated user."""
    db = get_db()
    user_id = get_current_user(info, db)
    user = db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        raise ValueError("User not found")
    user["id"] = str(user["_id"])
    del user["_id"]
    return user