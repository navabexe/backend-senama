import re
from datetime import datetime, UTC, timedelta

from ariadne import MutationType
from bson import ObjectId

from db import get_db
from models.session import Session
from models.user import User
from utils import create_access_token, create_refresh_token, generate_otp, get_password_hash, \
    get_current_user, ACCESS_TOKEN_EXPIRE_MINUTES, decode_refresh_token

mutation = MutationType()


@mutation.field("createUser")
async def resolve_create_user(_, info, phone, firstName=None, lastName=None, password=None, roles=["vendor"], bio=None,
                              avatarUrls=None, phones=None, birthdate=None, gender=None, languages=None):
    """Create a new user with optional profile details and assign a pending status with OTP."""
    db = get_db()
    if not re.match(r"^\+?[0-9]{10,14}$", phone):
        raise ValueError("Phone number format invalid (e.g., +989123456789 or 09123456789)")
    if db.users.find_one({"phone": phone}):
        raise ValueError(f"Phone {phone} already exists")

    otp = generate_otp()
    hashed_password = get_password_hash(password) if password else None
    user = User(
        phone=phone,
        first_name=firstName,
        last_name=lastName,
        password=hashed_password,
        roles=roles,
        status="pending",
        otp=otp,
        otp_expires_at=(datetime.now(UTC) + timedelta(minutes=5)).isoformat(),
        bio=bio,
        avatar_urls=avatarUrls or [],
        phones=phones or [],
        birthdate=birthdate,
        gender=gender,
        languages=languages or [],
        created_at=datetime.now(UTC).isoformat(),
        updated_at=datetime.now(UTC).isoformat()
    )
    result = db.users.insert_one(user.dict())
    user_id = str(result.inserted_id)
    user.id = user_id
    print(f"Created user with ID: {user_id}, OTP: {otp}")
    return {"id": user_id, "otp": otp}


@mutation.field("requestOtp")
async def resolve_request_otp(_, info, phone):
    """Request a new OTP for an existing user."""
    db = get_db()
    user = db.users.find_one({"phone": phone})
    if not user:
        raise ValueError(f"Phone {phone} not found")

    otp = generate_otp()
    db.users.update_one(
        {"_id": ObjectId(user["_id"])},
        {"$set": {"otp": otp, "otp_expires_at": (datetime.now(UTC) + timedelta(minutes=5)).isoformat()}}
    )
    print(f"Generated OTP for {phone}: {otp}")
    return {"id": str(user["_id"]), "otp": otp}


@mutation.field("verifyOtp")
async def resolve_verify_otp(_, info, phone, otp):
    """Verify OTP for a user and issue access and refresh tokens."""
    db = get_db()
    user = db.users.find_one({"phone": phone})
    if not user:
        raise ValueError("Phone not found")

    if "otp" not in user or "otp_expires_at" not in user:
        raise ValueError("No OTP found for this phone")

    expires_at = datetime.fromisoformat(user["otp_expires_at"])
    if user["otp"] != otp:
        raise ValueError("Invalid OTP")
    if expires_at < datetime.now(UTC):
        raise ValueError("OTP has expired")

    db.users.update_one({"_id": ObjectId(user["_id"])}, {"$unset": {"otp": "", "otp_expires_at": ""}})
    access_token = create_access_token(data={"sub": str(user["_id"])})
    refresh_token = create_refresh_token(data={"sub": str(user["_id"])})
    # زمان انقضای session رو با Access Token همگام می‌کنیم
    session_expiry = datetime.now(UTC) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    session = Session(
        user_id=str(user["_id"]),
        token=access_token,
        expires_at=session_expiry.isoformat(),
        created_at=datetime.now(UTC).isoformat()
    )
    result = db.sessions.insert_one(session.dict())
    session.id = str(result.inserted_id)
    print(
        f"Created session with ID: {session.id}, Access Token: {access_token}, Refresh Token: {refresh_token}, Session Expiry: {session_expiry}")
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "user_id": str(user["_id"])
    }


@mutation.field("refreshToken")
async def resolve_refresh_token(_, info, refreshToken):
    """Refresh an access token using a refresh token."""
    db = get_db()
    payload = decode_refresh_token(refreshToken)
    user_id = payload["sub"]
    session = db.sessions.find_one({"user_id": user_id})
    if not session:
        raise ValueError("No active session found")

    access_token = create_access_token(data={"sub": user_id})
    session_expiry = datetime.now(UTC) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    db.sessions.update_one(
        {"user_id": user_id},
        {"$set": {"token": access_token, "expires_at": session_expiry.isoformat()}}
    )
    print(f"Refreshed access token for user {user_id}: {access_token}, New Session Expiry: {session_expiry}")
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user_id": user_id
    }


@mutation.field("logoutUser")
async def resolve_logout_user(_, info):
    """Log out the current user by deleting their session."""
    db = get_db()
    user_id = get_current_user(info, db)
    token = info.context.get("request").headers.get("Authorization").split("Bearer ")[1]
    db.sessions.delete_one({"user_id": user_id, "token": token})
    return {"message": "Logged out successfully"}